package kr.co.shineware.nlp.komoran.admin.util.parser.stream;

import java.util.stream.Stream;

public interface StreamParser {
    static Stream<?> parse(String input) {
        return null;
    }
}

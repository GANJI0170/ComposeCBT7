package kr.co.shineware.nlp.komoran.admin.fwduser;

import kr.co.shineware.nlp.komoran.admin.AbstractRestIntegrationTest;
import org.junit.Before;
import org.junit.Test;

public class RestApiTest extends AbstractRestIntegrationTest {
    @Before
    public void init() {

    }

    @Test
    public void NothingYet_Test() {
        // Nothing Yet
    }
}

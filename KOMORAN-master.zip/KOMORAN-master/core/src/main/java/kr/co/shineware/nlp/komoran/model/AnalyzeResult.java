package kr.co.shineware.nlp.komoran.model;

public class AnalyzeResult {
	;
}

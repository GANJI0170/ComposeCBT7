kr.co.shineware.nlp.komoran.model
=================================

.. java:package:: kr.co.shineware.nlp.komoran.model

.. toctree::
   :maxdepth: 1

   KomoranResult

